<div class="photo show"> <img src="images/photos/rain.jpg" width="700"  title="Rainy"  alt=""  /> </div>
<div class="photo"> <img src="images/photos/car.jpg" width="700"  title="Old Car" alt=""  /> </div>
<div class="photo"> <img src="images/photos/mill.jpg" width="700"  title="The Mill"  alt=""  /> </div>
<div class="photo"> <img src="images/photos/redfield.jpg" width="700"  title="Redfield"  alt=""  /> </div>
<div class="photo"> <img src="images/photos/don-2.jpg" width="700"  title="Don River"  alt=""  /> </div>
<div class="photo"> <img src="images/photos/sundown.jpg" width="700"  title="Sundown"  alt=""  /> </div>
<div class="description">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut diam lectus, non adipiscing orci. Maecenas dapibus tellus vitae turpis vulputate ut aliquet nisl sodales. Fusce nec mauris sit amet odio placerat condimentum id at nunc.</p>
</div>
<div class="description">
  <p>Fivamus faucibus ipsum sed orci suscipit iaculis molestie odio porta. Pellentesque ac malesuada dui. Sed id ipsum orci. ivamus faucibus ipsum sed orci suscipit iaculis molestie odio porta. Pellentesque ac malesuada dui. Sed id ipsum orci.</p>
</div>
<div class="description">
  <p>Phasellus aliquam erat nec orci sagittis sit amet fringilla metus egestas. Aliquam ac ipsum quam, a luctus neque. Vestibulum a rutrum mauris.Maecenas dapibus tellus vitae turpis vulputate ut aliquet nisl sodales.</p>
</div>
<div class="description">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut diam lectus, non adipiscing orci. Maecenas dapibus tellus vitae turpis vulputate ut aliquet nisl sodales. Fusce nec mauris sit amet odio placerat condimentum id at nunc.</p>
</div>
<div class="description">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut diam lectus, non adipiscing orci. Maecenas dapibus tellus vitae turpis vulputate ut aliquet nisl sodales. Fusce nec mauris sit amet odio placerat condimentum id at nunc.</p>
</div>
<div class="description">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut diam lectus, non adipiscing orci. Maecenas dapibus tellus vitae turpis vulputate ut aliquet nisl sodales. Fusce nec mauris sit amet odio placerat condimentum id at nunc.</p>
</div>
<div id="photoDescr">
  <h2 class="photo-title"></h2>
  <div class="photo-description"></div>
</div>