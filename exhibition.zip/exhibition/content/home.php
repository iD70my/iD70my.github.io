<h2 class="content-heading">Wellcome to The Photo Exhibition</h2>
<div class="column">
  <p><strong>Photo Exhibition</strong> is a premium site template, designed by the <a target="_blank" class="blink" href="http://www.idangero.us" title="Premium Templates Scripts Graphics">iDangero.us</a> team. This <strong>template</strong> is intended for use as a photo portfolio with brief information about the author (photographer). The template is fully animated without the use of Flash technology. All animation realized through the use of jQuery and CSS3.</p>
  <img src="images/demo-photo2.png"  width="242" height="224" alt="" /> </div>
<div class="column"> <img src="images/demo-photo.png"  width="242" height="224" alt="" />
  <p>The main advantage of this <strong>template</strong> is that it uses only one page. Other content pages on the screen slides across the screen. This site and all its pages load at a time, no need to use internal links and no need to wait until the user loads the desired content.</p>
</div>
<div class="column">
  <p>It's very easy to redesign to redesign <strong>Photo Exhibition</strong>, it has very simple and clear API. Buying this template you will also get <strong>.PSD sources</strong> and detailed <strong>documentation</strong>.</p>
  <p>Smooth and good looking animation and ajax features of this template are realized by using the JavaScript jQuery library. </p>
  <p>So, it's time to checkout the main pages of the site:</p>
  <ul>
    <li><a class="blink" href="javascript:vSlide(1)">Photo Gallery</a></li>
    <li><a class="blink" href="javascript:vSlide(2)">About</a> Section</li>
    <li>Ajax <a class="blink" href="javascript:vSlide(3)">Contact Form</a> with validation</li>
  </ul>
</div>
