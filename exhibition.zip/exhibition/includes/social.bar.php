<div class="bar-icons">
<a href="#">
	<img class="bar-icon" src="images/social/twitter.png" width="40" alt="Twitter" title="Twitter" />
    <span>Twitter</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/facebook.png" width="40" height="63" alt="Facebook" title="Facebook" />
    <span>Facebook</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/flickr.png" width="40" height="63" alt="Flickr" title="Flickr" />
    <span>Flickr</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/delicious.png" width="40" height="63" alt="Delicious" title="Delicious" />
    <span>Delicious</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/blogger.png" width="40" height="63" alt="Blogger" title="Blogger" />
    <span>Blogger</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/myspace.png" width="40" height="63" alt="My Space" title="My Space" />
    <span>My&nbsp;Space</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/digg.png" width="40" height="63" alt="DIGG" title="DIGG" />
    <span>DIGG</span>
</a>
<a href="#">
	<img class="bar-icon" src="images/social/ytube.png" width="40" height="63" alt="YouTube" title="YouTube" />
    <span>You&nbsp;Tube</span>
</a>
</div>